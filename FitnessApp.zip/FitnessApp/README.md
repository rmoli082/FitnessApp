# Sehat Fitness

A fitness app for Android featuring a suite of fitness related utilities.

#### Bodyfat Calculator
#### BMI Calculator
#### Calorie Calculator
#### Macro Calculator
#### One-Rep-Max Calculator
#### Measurements Tracker
